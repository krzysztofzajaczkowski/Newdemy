<?php
/**
 * File: /upgrade/upgrade-2.3.php
 */
function upgrade_module_2_3($module) {
    // Process Module upgrade to 2.3
    // ....
    return true; // Return true if succes.
 }
?>
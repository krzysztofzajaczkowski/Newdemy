# Ap Page Builder

## About
Construction site: provide a method of building effective site, high flexibility, to create multi header and profile for the home page, product page.
The module will provide a full range of widgets with user friendly features for building websites for your shop as optimized for SEO, responsive design, multi header...

version 2.5.6
#add slick for thumb in mobile
#convert cache to default prestashop cache type
#fix random in product tab
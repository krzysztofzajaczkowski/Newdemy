<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mpm_footer}prestashop>mpm_footer_4e10a2c8ec0c44bfb7665e397b1bee6c'] = 'Footer block';
$_MODULE['<{mpm_footer}prestashop>mpm_footer_a889e609f051afbc518d87ba32562d88'] = 'Displays a footer on your shop.';
$_MODULE['<{mpm_footer}prestashop>mpm_footer_efc226b17e0532afff43be870bff0de7'] = 'The settings have been updated.';
$_MODULE['<{mpm_footer}prestashop>mpm_footer_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{mpm_footer}prestashop>mpm_footer_69ee1afc9b3d02e53d9f733c1993b568'] = 'Background image';
$_MODULE['<{mpm_footer}prestashop>mpm_footer_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{mpm_footer}prestashop>footer_block_a541ecda3d4c67f1151cad5075633423'] = '©';
$_MODULE['<{mpm_footer}prestashop>footer_block_361752d243da7c64ad6068d3a7c4cf5e'] = ' - Ecommerce software by PrestaShop™';

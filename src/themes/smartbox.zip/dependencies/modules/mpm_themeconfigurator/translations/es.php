<?php

  global $_MODULE;
  $_MODULE = array();
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_e92dabb4907f1957cabc469cca4deefc'] = 'Configurador de temas';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_f5a35b8e88be7f51ad3a3714a83df3a1'] = 'La herramienta de personalización te permite cambiar el color y la fuente de tu tema.';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_f4f70727dc34561dfde1a3c529b6205c'] = 'Ajustes';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_75ed15adfe00306633c8712fe8e32dd2'] = 'Color de fondo principal';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_9d5239857e6401bcb12a87a1691db03a'] = 'Por defecto: #d19e65';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_b79b039c903b748e2577fb083b634c17'] = 'Color de fondo principal al colocar el cursor encima';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_b39a0e730fd73d76514ad4652913730b'] = 'Por defecto: #ffffff';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_eddd2252e163c7ca51d0b068b6169c71'] = 'Fondo de página';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_bf79dd86ea56f36a705423139df6a4da'] = 'Color de fondo del pie de página';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_8c1ab413e6f9e57abfe35239d6a687df'] = 'Por defecto: #000000';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_c0ef1447efeab0af1d75099e77168e0d'] = 'Imagen de fondo del pie de página';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_010307371be5de844d863f3ebef685c3'] = 'Color del texto del pie de página';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_5dbd95201bae1e3ee5a1889b8fb2010d'] = 'Color del texto del pie al colocar el cursor encima';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_d96cdf8c6719bb08722cdb17b27cc57f'] = 'Fuente de la plantilla';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_194f5394ae2e9c74dc3c441b92862d1d'] = 'Fuente';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_eef726af49326ebfdf6816089c4229dc'] = 'Por defecto: Lato';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_9daf6056aa0d34486551a12e1d6b9163'] = 'Ajustes de categoría';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_b605530eb3bf38451e49daa30e1d2e68'] = 'Mostrar imagen de la categoría';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activado';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_b9f5c797ebbf55adccdd8539a65a0241'] = 'Desactivado';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_29c93e5b541f931139905702e890494a'] = 'Mostrar descripción de la categoría';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_4d4d488d19596e4c9bf2f889ee5020b3'] = 'Mostrar bloque de subcategorías en la página de categorías';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_e404bb156af00aa8398efd98c6994f53'] = 'Activar la ampliación de las imágenes de productos al poner el cursor encima';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_efc226b17e0532afff43be870bff0de7'] = 'Parámetros actualizados.';

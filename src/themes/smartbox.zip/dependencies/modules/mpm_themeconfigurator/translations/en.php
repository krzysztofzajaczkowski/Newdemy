<?php

  global $_MODULE;
  $_MODULE = array();
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_e92dabb4907f1957cabc469cca4deefc'] = 'Theme configurator';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_f5a35b8e88be7f51ad3a3714a83df3a1'] = 'The customization tool allows you to make color and font changes in your theme.';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_75ed15adfe00306633c8712fe8e32dd2'] = 'Main background color';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_9d5239857e6401bcb12a87a1691db03a'] = 'Default: #d19e65';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_b79b039c903b748e2577fb083b634c17'] = 'Main background color on hover';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_b39a0e730fd73d76514ad4652913730b'] = 'Default: #ffffff';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_eddd2252e163c7ca51d0b068b6169c71'] = 'Page background';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_bf79dd86ea56f36a705423139df6a4da'] = 'Background color in footer';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_8c1ab413e6f9e57abfe35239d6a687df'] = 'Default: #000000';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_c0ef1447efeab0af1d75099e77168e0d'] = 'Footer background image';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_010307371be5de844d863f3ebef685c3'] = 'Text color in footer';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_5dbd95201bae1e3ee5a1889b8fb2010d'] = 'Text color on hover in footer';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_d96cdf8c6719bb08722cdb17b27cc57f'] = 'Font of template';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_194f5394ae2e9c74dc3c441b92862d1d'] = 'Font';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_eef726af49326ebfdf6816089c4229dc'] = 'Default: Lato';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_9daf6056aa0d34486551a12e1d6b9163'] = 'Category settings';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_b605530eb3bf38451e49daa30e1d2e68'] = 'Display category image';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Enabled';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disabled';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_29c93e5b541f931139905702e890494a'] = 'Display category description';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_4d4d488d19596e4c9bf2f889ee5020b3'] = 'Display subcategories block on category page';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_e404bb156af00aa8398efd98c6994f53'] = 'Activate zoom for product images on hover';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
  $_MODULE['<{mpm_themeconfigurator}prestashop>mpm_themeconfigurator_efc226b17e0532afff43be870bff0de7'] = 'The settings have been updated.';

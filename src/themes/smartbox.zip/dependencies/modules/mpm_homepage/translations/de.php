<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mpm_homepage}prestashop>mpm_homepage_7b19b37e7fc3dfe3c3e1ad5b84c7f565'] = 'Homepage';
$_MODULE['<{mpm_homepage}prestashop>mpm_homepage_48dd3ecb925f5c7b1151752bb7ea6ab2'] = 'Home page content.';

<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mpm_social_buttons}prestashop>mpm_social_buttons_ce4ba083d3b31d01e0cff13b0b04c59e'] = 'Social buttons in footer';
$_MODULE['<{mpm_social_buttons}prestashop>mpm_social_buttons_3ecb750e56f91d074fb28498949fea38'] = 'Social buttons in footer.';
$_MODULE['<{mpm_social_buttons}prestashop>mpm_social_buttons_efc226b17e0532afff43be870bff0de7'] = 'Parámetros actualizados.';
$_MODULE['<{mpm_social_buttons}prestashop>mpm_social_buttons_f4f70727dc34561dfde1a3c529b6205c'] = 'Ajustes';
$_MODULE['<{mpm_social_buttons}prestashop>mpm_social_buttons_76f8961bb8f4bb2b95c07650f30a7e7b'] = 'URL de Facebook';
$_MODULE['<{mpm_social_buttons}prestashop>mpm_social_buttons_c162369096f0fe5784f05052ceee6b47'] = 'Su página de fans en Facebook.';
$_MODULE['<{mpm_social_buttons}prestashop>mpm_social_buttons_bcca29e10968edaf6e0154d2339ad556'] = 'URL de Twitter';
$_MODULE['<{mpm_social_buttons}prestashop>mpm_social_buttons_6aadf667dfc3538abc2708ba76861bba'] = 'Su cuenta oficial de Twitter.';
$_MODULE['<{mpm_social_buttons}prestashop>mpm_social_buttons_1a530e4877d8d41f810d9d05f065722d'] = 'RSS URL';
$_MODULE['<{mpm_social_buttons}prestashop>mpm_social_buttons_672f301ddc5372b2477ed3c1d9322949'] = 'El canal RSS de su elección (su blog, su tienda, etc.).';
$_MODULE['<{mpm_social_buttons}prestashop>mpm_social_buttons_ad7198d676478ac70c3243c1d3446331'] = 'YouTube URL';
$_MODULE['<{mpm_social_buttons}prestashop>mpm_social_buttons_5817a34292f074f9f596de6cb3607540'] = 'Su cuenta oficial de YouTube.';
$_MODULE['<{mpm_social_buttons}prestashop>mpm_social_buttons_1dd99e363d1bebee81578708c1e8a5e0'] = 'URL de Google +:';
$_MODULE['<{mpm_social_buttons}prestashop>mpm_social_buttons_1dd0a74974711190139fa51579765a04'] = 'Su página oficial de Google+.';
$_MODULE['<{mpm_social_buttons}prestashop>mpm_social_buttons_76abe3a162f22f63fae44d60fbe8f11b'] = 'Pinterest URL:';
$_MODULE['<{mpm_social_buttons}prestashop>mpm_social_buttons_e158a81859319b5e442bc490b0e81af3'] = 'Su página oficial de Pinterest.';
$_MODULE['<{mpm_social_buttons}prestashop>mpm_social_buttons_815f12ace0a25af8c12e036810002683'] = 'URL de Vimeo:';
$_MODULE['<{mpm_social_buttons}prestashop>mpm_social_buttons_cba991994fe165dfcf4f5bd256bbe119'] = 'Su cuenta oficial de Vimeo.';
$_MODULE['<{mpm_social_buttons}prestashop>mpm_social_buttons_130bab903955b2f6047a0db82f460386'] = 'URL en Instagram:';
$_MODULE['<{mpm_social_buttons}prestashop>mpm_social_buttons_d55a27c3408d38f3137182c89b69a7a7'] = 'Tu cuenta oficial de Instagram.';
$_MODULE['<{mpm_social_buttons}prestashop>mpm_social_buttons_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';

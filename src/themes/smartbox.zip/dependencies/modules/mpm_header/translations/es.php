<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mpm_header}prestashop>mpm_header_c3d26cb95cd31ac8b278def23c0279d3'] = 'Store header';
$_MODULE['<{mpm_header}prestashop>mpm_header_f9ad1a8108d0f4f82e8a5ba5a9c401eb'] = 'Displays a header on your shop.';
$_MODULE['<{mpm_header}prestashop>header_block_a8d2a21438623603c4e0e47df527be62'] = '¡Mensaje de bienvenida!';
